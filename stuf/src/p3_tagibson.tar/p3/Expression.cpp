// File: Expression.cpp
#include "Expression.h"
#include "Constant.h"
#include "error.h"
#include <string>
#include <cmath>
using std::string;

Expression::~Expression() { delete evaluated_constant; }

// This wrapper ensures that Constant objects created by evaluate() are
// properly released when a subsequent call to evaluate() will otherwise
// overwrite the pointer.
const Constant *Expression::ret(const Constant *new_evald_constant) const
{
  delete evaluated_constant;
  return evaluated_constant = new_evald_constant;
}
/**********************************************/
/************* Other operators ****************/
/**********************************************/

const Constant *Plus::evaluate() const
{
  GPL::Type lht = lhs->type();
  GPL::Type rht = rhs->type();
  const Constant *lhs_constant = lhs->evaluate();
  const Constant *rhs_constant = rhs->evaluate();
  if (lht == GPL::STRING || rht == GPL::STRING)
    return ret(new String_constant(lhs_constant->as_string() + //<--addition
                                   rhs_constant->as_string()));
  if (lht == GPL::DOUBLE || rht == GPL::DOUBLE)
    return ret(new Double_constant(lhs_constant->as_double() + //<--addition
                                   rhs_constant->as_double()));
  return ret(new Integer_constant(lhs_constant->as_int() + //<--addition
                                  rhs_constant->as_int()));

  return nullptr; // REPLACE THIS. Here to suppress errors.
}

GPL::Type Plus::type() const
{
  GPL::Type lht = lhs->type();
  GPL::Type rht = rhs->type();
  if (lht == GPL::STRING || rht == GPL::STRING)
    return GPL::STRING;
  if (lht == GPL::DOUBLE || rht == GPL::DOUBLE)
    return GPL::DOUBLE;
  return GPL::INT;
  // return GPL::NO_TYPE; //REPLACE THIS. Here to suppress errors.
}
/*###########################*/
/*###########################*/
/*    MULTIPLY RULE          */
/*###########################*/
/*###########################*/


const Constant *Multiply::evaluate() const
{
  const Constant* lhs_constant=lhs->evaluate();
  const Constant* rhs_constant=rhs->evaluate();
  if(lhs->type()==GPL::DOUBLE || rhs->type()==GPL::DOUBLE)
    return ret(new Double_constant(lhs_constant->as_double() * //<--multiply
                                   rhs_constant->as_double()));
  return ret(new Integer_constant(lhs_constant->as_int() *     //<--multiply
                                  rhs_constant->as_int()));
  //return nullptr; // REPLACE THIS. Here to suppress errors.
}

GPL::Type Multiply::type() const
{
  GPL::Type lht=lhs->type();
  GPL::Type rht=rhs->type();
  if(lht==GPL::DOUBLE || rht==GPL::DOUBLE)
    return GPL::DOUBLE;
  return GPL::INT;
  //return GPL::NO_TYPE; // REPLACE THIS. Here to suppress errors.
}
/*###########################*/
/*###########################*/
/*       MINUS RULE          */
/*###########################*/
/*###########################*/


const Constant *Minus::evaluate() const
{
  const Constant* lhs_constant=lhs->evaluate();
  const Constant* rhs_constant=rhs->evaluate();
  if(lhs->type()==GPL::DOUBLE || rhs->type()==GPL::DOUBLE)
    return ret(new Double_constant(lhs_constant->as_double() - //<--Subtract
                                   rhs_constant->as_double()));
  return ret(new Integer_constant(lhs_constant->as_int() -     //<--Subtract
                                  rhs_constant->as_int()));
  //return nullptr; // REPLACE THIS. Here to suppress errors.
}

GPL::Type Minus::type() const
{
  GPL::Type lht=lhs->type();
  GPL::Type rht=rhs->type();
  if(lht==GPL::DOUBLE || rht==GPL::DOUBLE)
    return GPL::DOUBLE;
  return GPL::INT;
  //return GPL::NO_TYPE; // REPLACE THIS. Here to suppress errors.
}
/*###########################*/
/*###########################*/
/*       DIVIDE RULE         */
/*###########################*/
/*###########################*/


const Constant *Divide::evaluate() const
{
  const Constant* lhs_constant=lhs->evaluate();
  const Constant* rhs_constant=rhs->evaluate();
  if(lhs->type()==GPL::DOUBLE || rhs->type()==GPL::DOUBLE)
    return ret(new Double_constant(lhs_constant->as_double() / //<--Divide
                                   rhs_constant->as_double()));
  return ret(new Integer_constant(lhs_constant->as_int() /     //<--Divide
                                  rhs_constant->as_int()));
  //return nullptr; // REPLACE THIS. Here to suppress errors.
}

GPL::Type Divide::type() const
{
  GPL::Type lht=lhs->type();
  GPL::Type rht=rhs->type();
  if(lht==GPL::DOUBLE || rht==GPL::DOUBLE)
    return GPL::DOUBLE;
  return GPL::INT;
}
/*###########################*/
/*###########################*/
/*       MOD RULE            */
/*###########################*/
/*###########################*/


const Constant *Mod::evaluate() const
{
  const Constant* lhs_constant=lhs->evaluate();
  const Constant* rhs_constant=rhs->evaluate();
  return ret(new Integer_constant(lhs_constant->as_int() %     //<--Or
                                  rhs_constant->as_int()));
}


GPL::Type Mod::type() const
{
  return GPL::INT;
}
/*###########################*/
/*###########################*/
/*        OR RULE            */
/*###########################*/
/*###########################*/


const Constant *Or::evaluate() const
{
  const Constant* lhs_constant=lhs->evaluate();
  const Constant* rhs_constant=rhs->evaluate();
  return ret(new Integer_constant(lhs_constant->as_int() %     //<--Multiply
                                  rhs_constant->as_int()));
  //return nullptr; // REPLACE THIS. Here to suppress errors.
}

GPL::Type Or::type() const
{
  GPL::Type lht=lhs->type();
  GPL::Type rht=rhs->type();
  if(lht==GPL::DOUBLE || rht==GPL::DOUBLE)
    return GPL::DOUBLE;
  return GPL::INT;//return GPL::NO_TYPE; // REPLACE THIS. Here to suppress errors.
}
/*###########################*/
/*###########################*/
/*        AND RULE            */
/*###########################*/
/*###########################*/


const Constant *And::evaluate() const
{
  const Constant* lhs_constant=lhs->evaluate();
  const Constant* rhs_constant=rhs->evaluate();
  if(lhs->type()==GPL::DOUBLE || rhs->type()==GPL::DOUBLE)
    return ret(new Double_constant(lhs_constant->as_double() && //<--And
                                   rhs_constant->as_double()));
  return ret(new Integer_constant(lhs_constant->as_int() &&     //<--And
                                  rhs_constant->as_int()));//return nullptr; // REPLACE THIS. Here to suppress errors.
}

GPL::Type And::type() const
{
  GPL::Type lht=lhs->type();
  GPL::Type rht=rhs->type();
  if(lht==GPL::DOUBLE || rht==GPL::DOUBLE)
    return GPL::DOUBLE;
  return GPL::INT;
  //return GPL::NO_TYPE; // REPLACE THIS. Here to suppress errors.
}